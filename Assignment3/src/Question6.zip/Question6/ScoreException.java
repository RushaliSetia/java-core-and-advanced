package Question6;

public class ScoreException extends Exception 
{
     public ScoreException(String string) {
		System.out.println(string);
	}
}
