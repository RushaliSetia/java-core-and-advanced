package Question6;

public class Student {
	private int stdID;
	private int marks;

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int stdID, int marks) {
		super();
		this.stdID = stdID;
		this.marks = marks;
	}

	public int getStdID() {
		return stdID;
	}

	public int getMarks() {
		return marks;
	}
	
	

}